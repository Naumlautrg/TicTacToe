#include "TicTacToeAI.h"

void TicTacToeEngine::loadAIMove(int moveIndex)
{
	if (moveIndex % 4 == 0)
	{
		AIMoveIndexes["diag1"].push_back(moveIndex);
	}


	if ((moveIndex % 2 == 0) && !(moveIndex % 4 == 0))
	{
		AIMoveIndexes["diag2"].push_back(moveIndex);
	}

	if (moveIndex == 4)
	{
		AIMoveIndexes["diag2"].push_back(moveIndex);
	}




	if ((moveIndex % 3) == 0)
	{
		AIMoveIndexes["col1"].push_back(moveIndex);


		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				AIMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			AIMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		AIMoveIndexes["row3"].push_back(moveIndex);
		return;
	}

	if ((moveIndex % 3) == 1)
	{
		AIMoveIndexes["col2"].push_back(moveIndex);

		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				AIMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			AIMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		AIMoveIndexes["row3"].push_back(moveIndex);
		return;
	}

	if ((moveIndex % 3) == 2)
	{
		AIMoveIndexes["col3"].push_back(moveIndex);

		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				AIMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			AIMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		AIMoveIndexes["row3"].push_back(moveIndex);
		return;
	}
}

void TicTacToeEngine::loadPlayerMove(int moveIndex)
{
	if (moveIndex % 4 == 0)
	{
		playerMoveIndexes["diag1"].push_back(moveIndex);
	}


	if ((moveIndex % 2 == 0) && !(moveIndex % 4 == 0))
	{
		playerMoveIndexes["diag2"].push_back(moveIndex);
	}

	if (moveIndex == 4)
	{
		playerMoveIndexes["diag2"].push_back(moveIndex);
	}




	if ((moveIndex % 3) == 0)
	{
		playerMoveIndexes["col1"].push_back(moveIndex);


		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				playerMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			playerMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		playerMoveIndexes["row3"].push_back(moveIndex);
		return;
	}

	if ((moveIndex % 3) == 1)
	{
		playerMoveIndexes["col2"].push_back(moveIndex);

		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				playerMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			playerMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		playerMoveIndexes["row3"].push_back(moveIndex);
		return;
	}

	if ((moveIndex % 3) == 2)
	{
		playerMoveIndexes["col3"].push_back(moveIndex);

		if (moveIndex < 6)
		{
			if (moveIndex < 3)
			{
				playerMoveIndexes["row1"].push_back(moveIndex);
				return;
			}

			playerMoveIndexes["row2"].push_back(moveIndex);
			return;
		}

		playerMoveIndexes["row3"].push_back(moveIndex);
		return;
	}
}

bool TicTacToeEngine::checkWinCon(const char playerOrAI)
{

	// for an ai win check
	if (toupper(playerOrAI) == 'A')
	{
		for (auto& pair : AIMoveIndexes)
		{
			if (pair.second.size() == 3)
			{
				return true;
			}
		}
	}

	// for a player win check
	else if (toupper(playerOrAI) == 'P')
	{
		for (auto& pair : playerMoveIndexes)
		{
			if (pair.second.size() == 3)
			{
				return true;
			}
		}
	}

	return false;
}

TicTacToeEngine::TicTacToeEngine()
{
	AIMoveIndexes = {
		{"col1", {}},
		{"col2", {}},
		{"col3", {}},
		{"row1", {}},
		{"row2", {}},
		{"row3", {}},
		{"diag1", {}},
		{"diag2", {}},
	};

	playerMoveIndexes = {
		{"col1", {}},
		{"col2", {}},
		{"col3", {}},
		{"row1", {}},
		{"row2", {}},
		{"row3", {}},
		{"diag1", {}},
		{"diag2", {}},
	};

}

void TicTacToeEngine::generateMove()
{
	int move = generateNum((spotChoices.size() - 1));

	std::cout << "Hmmmmm.....";
	std::this_thread::sleep_for(std::chrono::milliseconds(1200));
	std::cout << "I choose spot number " << spotChoices[move] << "\n\n";

	loadAIMove(spotChoices[move] - 1);

	if (checkWinCon('A'))
	{
		
	}

	spotChoices.erase(spotChoices.begin() + move);

}

void TicTacToeEngine::readPlayerMove()
{
	for (int i = 0; i < 100; ++i)
	{
		int pMove;

		std::cout << "What is your move?  ";
		std::cin >> pMove;
		std::cout << "\n\n";

		auto pMoveIndex = std::find(spotChoices.begin(), spotChoices.end(), pMove);

		if (pMoveIndex != spotChoices.end())
		{
			spotChoices.erase(pMoveIndex);
			loadPlayerMove(pMove - 1);
			return;
		}

		std::cout << "Invalid spot, please pick a spot on the board that has not been chosen\n\n";

	}

	std::cout << "You are really somethin ay?";
	std::this_thread::sleep_for(std::chrono::seconds(5));
	std::exit(1);
}