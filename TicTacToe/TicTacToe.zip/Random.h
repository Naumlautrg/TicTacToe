#pragma once
#include <random>

class Random
{
protected:

	std::mt19937 gen;


public:

	Random();
		

	int generateNum(int max);
	

};

