#include "TicTacToeGame.h"

void TicTacToeGame::startGame()
{

	printBoard();
	
	std::cout << "Ready to play? (Y/N):  ";
	std::cin >> play;

	playGame();

	std::cout << "\n\nFarewell";
	std::this_thread::sleep_for(std::chrono::seconds(1));
}

void TicTacToeGame::printBoard()
{
	std::cout << "Board Layout:\n" << " 1 | 2 | 3 \n-----------\n 4 | 5 | 6 \n-----------\n 7 | 8 | 9 \n\n";
}

void TicTacToeGame::playGame()
{
	while (std::toupper(play) == 'Y')
	{
		bool gameWon = false;

		TicTacToeEngine steve;
		int firstPlay = steve.generateNum(1);

		std::cout << "Let's play\n\n";

		if (firstPlay == 0)
		{
			std::cout << "I will go first.\n";

			while (!steve.spotChoices.empty())
			{
				steve.generateMove();
				if (steve.checkWinCon('A'))
				{
					gameWon = true;
					std::cout << "YAY!! I Win!!\n\n";
					std::cout << "Would you like to play again? (Y/N)  ";
					std::cin >> play;
					std::cout << "\n\n";
					break;
				}



				if (!steve.spotChoices.empty())
				{
					steve.readPlayerMove();
				}


				if (steve.checkWinCon('P'))
				{
					gameWon = true;
					std::cout << "Coongrats!! You Win!!\n\n";
					std::cout << "Would you like to play again? (Y/N)  ";
					std::cin >> play;
					std::cout << "\n\n";
					break;
				}

			}
		}

		if (firstPlay == 1)
		{
			std::cout << "You go first.\n\n";

			while (!steve.spotChoices.empty())
			{
				steve.readPlayerMove();
				if (steve.checkWinCon('P'))
				{
					gameWon = true;
					std::cout << "Coongrats!! You Win!!\n\n";
					std::cout << "Would you like to play again? (Y/N)  ";
					std::cin >> play;
					std::cout << "\n\n";
					break;
				}

				if (!steve.spotChoices.empty())
				{
					steve.generateMove();
				}

				if (steve.checkWinCon('A'))
				{
					gameWon = true;
					std::cout << "YAY!! I Win!!\n\n";
					std::cout << "Would you like to play again? (Y/N)  ";
					std::cin >> play;
					std::cout << "\n\n";
					break;
				}
			}
		}

		if (!gameWon) //(!(steve.checkWinCon('A') && steve.checkWinCon('P')))
		{
			std::cout << "Cat's game...\nWould you like to play again? (Y/N):  ";
			std::cin >> play;
			std::cout << "\n\n\n";
		}

	}
}

