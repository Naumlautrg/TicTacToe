#pragma once
#include "TicTacToeAI.h"

class TicTacToeGame
{
private:

	char play = 'Y';
	void printBoard();
	
	void playGame();

public:

	void startGame();

	
	
};
